/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zavrsni.gamestore.util;

import org.hibernate.Session;
import zavrsni.gamestore.controller.ControllerGame;
import zavrsni.gamestore.model.Game;

/**
 *
 * @author Korisnik
 */
public class CreateGames {

}
