/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zavrsni.gamestore.view;

import zavrsni.gamestore.model.User;

/**
 *
 * @author Korisnik
 */
public class Application {
    
    public static final String TITLE_APP="Gamestore";
    public static User user;
    
}
